import UIKit


var pointMoney = 2000
var memberMonth = 5


if pointMoney < 1000 {
     print("적립금을 사용할 수 없습니다.")
}else{
     if memberMonth < 3 {
          print("가입한 지 3개월이 지나지 않았기 때문에 적립금을 사용할 수 없습니다.")
     }else{
          print("적립금을 사용할 수 있습니다.")
     }
}

